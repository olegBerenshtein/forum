

public class Test {

    @org.junit.Test
    public void containTest(){
        String str1 = "я вышел погулять";
        System.out.println(str1.contains("вышел"));

        String abc = "abcd  ef";
        System.out.println(abc.contains("abcd ef"));
    }

    @org.junit.Test
    public void ifTest(){

    }
}
